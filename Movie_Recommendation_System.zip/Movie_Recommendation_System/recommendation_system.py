import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from scipy.sparse import csr_matrix
from sklearn.neighbors import NearestNeighbors

# Sample Data: Product catalog and user interactions
products = pd.DataFrame({
    'product_id': [1, 2, 3, 4, 5],
    'name': ["Laptop", "Headphones", "Keyboard", "Mouse", "Smartphone"],
    'category': ["Electronics", "Electronics", "Electronics", "Electronics", "Electronics"],
    'description': [
        "High-performance laptop with 16GB RAM",
        "Noise-cancelling over-ear headphones",
        "Mechanical keyboard with RGB lighting",
        "Wireless optical mouse",
        "Latest smartphone with 5G support"
    ]
})

user_interactions = pd.DataFrame({
    'user_id': [1, 1, 2, 2, 3, 3, 3],
    'product_id': [1, 2, 2, 3, 4, 5, 1],
    'rating': [5, 4, 5, 4, 4, 5, 3]  # Ratings given by users
})

# Content-Based Filtering

def content_based_recommendations(product_id, products, top_n=3):
    # Vectorize the product descriptions
    tfidf = TfidfVectorizer(stop_words='english')
    tfidf_matrix = tfidf.fit_transform(products['description'])

    # Compute cosine similarity
    cosine_sim = cosine_similarity(tfidf_matrix, tfidf_matrix)

    # Get the similarity scores for the given product_id
    product_idx = products[products['product_id'] == product_id].index[0]
    similarity_scores = list(enumerate(cosine_sim[product_idx]))

    # Sort and get top_n recommendations
    sorted_scores = sorted(similarity_scores, key=lambda x: x[1], reverse=True)
    top_products = [products.iloc[i[0]]['name'] for i in sorted_scores[1:top_n + 1]]

    return top_products

# Collaborative Filtering

def collaborative_filtering_recommendations(user_id, user_interactions, products, top_n=3):
    # Create a user-item matrix
    user_item_matrix = user_interactions.pivot(index='user_id', columns='product_id', values='rating').fillna(0)

    # Adjust top_n if it exceeds the number of users
    adjusted_top_n = min(top_n, user_item_matrix.shape[0] - 1)

    # Sparse matrix for efficiency
    sparse_matrix = csr_matrix(user_item_matrix)

    # Fit NearestNeighbors model
    model = NearestNeighbors(metric='cosine', algorithm='brute')
    model.fit(sparse_matrix)

    # Find similar users
    user_idx = user_item_matrix.index.tolist().index(user_id)
    distances, indices = model.kneighbors(sparse_matrix[user_idx], n_neighbors=adjusted_top_n + 1)

    # Get recommendations from similar users
    similar_users = indices.flatten()[1:]
    recommended_products = set()
    for sim_user in similar_users:
        sim_user_products = user_item_matrix.iloc[sim_user].sort_values(ascending=False)
        recommended_products.update(sim_user_products[sim_user_products > 0].index.tolist())

    # Exclude already interacted products
    interacted_products = set(user_interactions[user_interactions['user_id'] == user_id]['product_id'].tolist())
    recommended_products -= interacted_products

    return products[products['product_id'].isin(recommended_products)]['name'].tolist()

# Example Usage
print("Content-Based Recommendations for Product 1:")
print(content_based_recommendations(1, products))

print("\nCollaborative Filtering Recommendations for User 1:")
print(collaborative_filtering_recommendations(1, user_interactions, products))
